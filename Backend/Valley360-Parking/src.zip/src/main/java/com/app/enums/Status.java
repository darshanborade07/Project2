package com.app.enums;

public enum Status {

	AVAILABLE, NOT_AVAILABLE
}
