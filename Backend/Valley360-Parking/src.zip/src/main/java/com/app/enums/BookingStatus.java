package com.app.enums;

public enum BookingStatus {

	RESERVED, ACTIVE, COMPLETED, CANCELLED 
}
