package com.app.enums;

public enum RoleEnum {
	ROLE_ADMIN, ROLE_OWNER, ROLE_CUSTOMER
}
