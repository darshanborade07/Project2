package com.app.service;

import com.app.entities.User;

public interface AdminService {

	String login(String email, String password);
}
