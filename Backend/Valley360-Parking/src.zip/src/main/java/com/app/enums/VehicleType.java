package com.app.enums;

public enum VehicleType {

	TWO_WHEELER, FOUR_WHEELER
}
